const express = require("express");
const webpush = require("web-push");
const bodyParser = require("body-parser");
const path = require("path");
const mysql = require("mysql");
const app = express();

donnesDb = {};
fonctionsDb = {};

tete = {};
description = {};

i = 0;
j=0;

var IdNotif = new Array();
var my_ID = new Array();



//DataBase connection
  const con = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'mobilitypush'
  });

  

   //getDATA
   con.query('SELECT MUS_IDUSER, MUS_LOGIN, MUS_FONCTION FROM mb_users where MUS_FONCTION=\'commercant\'', (err,data) =>{
    console.log('Data received from Db:'+"\n");
    for(i=0;i<data.length;i++){
    console.log(data[i].MUS_LOGIN + " est un : " + data[i].MUS_FONCTION);
    this.donnesDb = data[i].MUS_LOGIN;
    this.fonctionsDb = data[i].MUS_FONCTION;
    console.log("----------");
    my_ID.push(data[i].MUS_IDUSER);
    //console.log(data.length);
    }
    console.log(my_ID);
    k=0;
    for(j=0;j<my_ID.length;j++){
      con.query('SELECT MEN_IDNOTIFICATION from MB_ENVOIE where MEN_IDUSER ='+my_ID[j],(err,rows)=>{
        
        console.log("ID de la notification : " + rows[0].MEN_IDNOTIFICATION);
        this.IdNotif = IdNotif.push(rows[0].MEN_IDNOTIFICATION);
        //console.log(IdNotif + " La taille  :" + IdNotif.length);
        
        con.query('SELECT MNO_CIBLE, MNO_TITRE, MNO_DESCRIPTION from MB_NOTIFCATIONS where MNO_IDNOTIFICATION='+IdNotif[k],(err,donnee)=>{
          this.tete= donnee[0].MNO_TITRE;
          this.description = donnee[0].MNO_DESCRIPTION; 
          //console.log(donnee[0].MNO_CIBLE);
          if(!err)
          con.query('UPDATE MB_NOTIFCATIONS set MNO_ETAT = 1 where MNO_IDNOTIFICATION='+IdNotif[k]);
          else
          con.query('UPDATE MB_NOTIFCATIONS set MNO_ETAT = 0 where MNO_IDNOTIFICATION='+IdNotif[k]);

    k++;
        });
        
      });
    }

    
  });
  

  
// Set static path
app.use(express.static(path.join(__dirname, "client")));

app.use(bodyParser.json());

const publicVapidKey  =  "BJthRQ5myDgc7OSXzPCMftGw-n16F7zQBEN7EUD6XxcfTTvrLGWSIG7y_JxiWtVlCFua0S8MTB5rPziBqNx1qIo";
const privateVapidKey =  "3KzvKasA2SoCxsp0iIG_o9B0Ozvl1XDwI63JRKNIWBM";

webpush.setVapidDetails("mailto:hramchi.hamza@gmail.com",publicVapidKey,privateVapidKey);

// Subscribe Route
  app.post("/subscribe", (req, res) => {
  // Get pushSubscription object
  const subscription = req.body;

  // Send 201 - resource created
  res.status(201).json({});

  // Create payload
  const payload = JSON.stringify({ title: this.tete, donnees : this.description});
  

  // Pass object into sendNotification
  webpush
    .sendNotification(subscription, payload)
    .catch(err => console.error(err));
});


const port = 2096;

app.listen(port, () => console.log(`Server started on port ${port}`));







